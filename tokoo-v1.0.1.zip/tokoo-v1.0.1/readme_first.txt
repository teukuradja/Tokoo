Tokoo - WooCommerce Wordpress Theme

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://docs.madrasthemes.com/tokoo/
2. Support - https://madrasthemes.freshdesk.com/
3. Getting Started with WooCommerce - https://docs.woothemes.com/documentation/plugins/woocommerce/getting-started/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress